import java.util.*;

public class Partido {
    Set<Participante> participantes;
    List<Jugador> jugadores;
    List<JugadorLocal> jugadoresLocales;
    List<JugadorVisitante> jugadorVisitantes;
    List<Arbitro> arbitros;
    Map<String, List<Integer>> puntuacionesJugador;
    final Random random;


    public Partido() {
        this.participantes = new HashSet<>();
        this.jugadoresLocales = new  ArrayList<>();
        this.jugadorVisitantes = new  ArrayList<>();
        this.arbitros = new ArrayList<>();
        this.puntuacionesJugador = new HashMap<>();
        this.jugadores = new ArrayList<>(jugadoresLocales);
        this.random = new  Random();
    }

    public void generarListasParticipantesSeparadas() {

        for (Participante participante : participantes) {
            if (participante instanceof JugadorLocal) {
                jugadoresLocales.add((JugadorLocal) participante);
            }

            if (participante instanceof JugadorVisitante) {
                jugadorVisitantes.add((JugadorVisitante) participante);
            }

            if (participante instanceof Arbitro) {
                arbitros.add((Arbitro) participante);
            }
        }

    }

    public List<Jugador> getJugadoresOrdenadosEdadNacionalidad() {

        List<Jugador> todosLosJugadores = new ArrayList<>();

        for (Jugador jugador : jugadoresLocales) {
            JugadorLocal  jugadorLocal = (JugadorLocal) jugador;
            todosLosJugadores.add(jugador);
        }

        for (Jugador jugador : jugadorVisitantes) {
            JugadorVisitante jugadorVisitante = (JugadorVisitante) jugador;
            todosLosJugadores.add(jugadorVisitante);
        }

        todosLosJugadores.stream().forEach(System.out::println);
        return todosLosJugadores;

    }

    public List<Jugador> getJugadoresLocalesOrdenadosAltura() {

        List<Jugador> jugadoresLocalesOrdenadosAltura = new ArrayList<>();

        for (Jugador jugador : jugadoresLocales) {
            if (jugador instanceof JugadorLocal) {
                jugadoresLocalesOrdenadosAltura.add(jugador);
            }
        }

        System.out.println(jugadoresLocalesOrdenadosAltura);

        return jugadoresLocalesOrdenadosAltura;

    }

    public List<Jugador> getJugadoresVisitantesOrdenadosDorsal() {

        List<Jugador> jugadoresVisitantesOrdenadosDorsal = new ArrayList<>();

        for (Jugador jugador : jugadorVisitantes) {
            if (jugador instanceof JugadorLocal) {
                jugadoresVisitantesOrdenadosDorsal.add(jugador);
            }
        }

        System.out.println(jugadoresVisitantesOrdenadosDorsal);
        return jugadoresVisitantesOrdenadosDorsal;

    }

    public int getPuntosJugadorEnCuarto(String nombreJugador, int numeroCuarto) {

        Random random = new Random();
        numeroCuarto = random.nextInt(1, 4);

        if (!puntuacionesJugador.containsKey(nombreJugador)) {
            puntuacionesJugador.put(nombreJugador, new ArrayList<>());
        } else {
            puntuacionesJugador.get(nombreJugador).add(numeroCuarto);

        }

        return puntuacionesJugador.get(nombreJugador).size();
    }

    public void jugar() {
        for (int i = 0; i < 400 ; i++) {

            Iterator<JugadorLocal> iterator = jugadoresLocales.iterator();
            Iterator<JugadorVisitante> iteratorVisitante = jugadorVisitantes.iterator();
            Iterator<Arbitro> iteratorArbitro = arbitros.iterator();

            while (iterator.hasNext()) {

                JugadorLocal  jugadorLocal = iterator.next();
                Arbitro  arbitro = iteratorArbitro.next();

                String realizarAccionJugador1 = jugadorLocal.accion();
                String realizarAccionArbitro = arbitro.accion();

                if (realizarAccionJugador1.equals("MATE") ||  realizarAccionJugador1.equals("TIRO_2_PUNTOS") || realizarAccionArbitro.equals("ANOTAR_2_PUNTOS")) {
                    List<Integer> canasta1 = new ArrayList<>();
                    canasta1.add(2);

                    if (!puntuacionesJugador.containsKey(realizarAccionJugador1)) {
                        puntuacionesJugador.put(jugadorLocal.nombre, new ArrayList<>());
                    }

                    puntuacionesJugador.put(jugadorLocal.nombre, canasta1);

                }

                if (realizarAccionJugador1.equals("TIRO_1_PUNTO") || realizarAccionArbitro.equals("ANOTAR_1_PUNTO")) {
                    List<Integer> canasta2 = new ArrayList<>();
                    canasta2.add(1);

                    if (!puntuacionesJugador.containsKey(realizarAccionJugador1)) {
                        puntuacionesJugador.put(jugadorLocal.nombre, new ArrayList<>());
                    }

                    puntuacionesJugador.put(jugadorLocal.nombre, canasta2);

                }

                if (realizarAccionJugador1.equals("TIRO_3_PUNTOS") || realizarAccionArbitro.equals("ANOTAR_3_PUNTOS")) {
                    List<Integer> canasta3 = new ArrayList<>();
                    canasta3.add(3);

                    if (!puntuacionesJugador.containsKey(realizarAccionJugador1)) {
                        puntuacionesJugador.put(jugadorLocal.nombre, new ArrayList<>());
                    }

                    puntuacionesJugador.put(jugadorLocal.nombre, canasta3);

                }

            }


        }

    }















    private void rellenarListaParticipantes() {
       /*
        ESTE METODO NO SE PUEDE MODIFICAR
        */
        // Jugadores Pamesa Valencia (LOCALES)
        Participante jl1 = new JugadorLocal("VLC01", "Víctor Luengo", "Española", 32, 15, "Escolta", false, "Pamesa Valencia", 196);
        Participante jl2 = new JugadorLocal("VLC02", "Nacho Rodilla", "Española", 30, 11, "Base", false, "Pamesa Valencia", 192);
        Participante jl3 = new JugadorLocal("VLC03", "Bernard Hopkins", "USA", 31, 12, "Ala-Pívot", false, "Pamesa Valencia", 197);
        Participante jl4 = new JugadorLocal("VLC01", "Víctor Luengo", "Española", 32, 15, "Escolta", false, "Pamesa Valencia", 196);
        Participante jl5 = new JugadorLocal("VLC04", "Fabricio Oberto", "Argentina", 27, 7, "Pívot", false, "Pamesa Valencia", 208);
        Participante jl6 = new JugadorLocal("VLC05", "Rafa Martínez", "Española", 34, 17, "Escolta", false, "Pamesa Valencia", 190);
        Participante jl7 = new JugadorLocal("VLC06", "Bojan Dubljevic", "Montenegro", 29, 14, "Pívot", false, "Pamesa Valencia", 205);
        Participante jl8 = new JugadorLocal("VLC07", "Dejan Tomasevic", "Serbia", 30, 13, "Pívot", false, "Pamesa Valencia", 208);
        Participante jl9 = new JugadorLocal("VLC08", "Chris Jones", "USA", 30, 7, "Base", false, "Pamesa Valencia", 188);

        participantes.add(jl1);participantes.add(jl2);participantes.add(jl3);participantes.add(jl4);
        participantes.add(jl5);participantes.add(jl6);participantes.add(jl7);participantes.add(jl8);participantes.add(jl9);


        // Jugadores Real Madrid (VISITANTES)
        Participante jv1 = new JugadorVisitante("RMD01", "Sergio Llull", "Española", 36, 23, "Base", false, "Real Madrid", 190);
        Participante jv2 = new JugadorVisitante("RMD02", "Walter Tavares", "Cabo Verde", 31, 22, "Pívot", false, "Real Madrid", 220);
        Participante jv3 = new JugadorVisitante("RMD03", "Facundo Campazzo", "Argentina", 32, 7, "Base", false, "Real Madrid", 181);
        Participante jv4 = new JugadorVisitante("RMD04", "Rudy Fernández", "Española", 38, 5, "Alero", false, "Real Madrid", 196);
        Participante jv5 = new JugadorVisitante("RMD05", "Mario Hezonja", "Croacia", 28, 11, "Alero", false, "Real Madrid", 203);
        Participante jv6 = new JugadorVisitante("RMD06", "Dzanan Musa", "Bosnia", 24, 31, "Escolta", false, "Real Madrid", 205);
        Participante jv7 = new JugadorVisitante("RMD07", "Guerschon Yabusele", "Francia", 28, 28, "Ala-Pívot", false, "Real Madrid", 204);
        Participante jv8 = new JugadorVisitante("RMD08", "Gabriel Deck", "Argentina", 29, 14, "Alero", false, "Real Madrid", 198);

        participantes.add(jv1);participantes.add(jv2);participantes.add(jv3);participantes.add(jv4);
        participantes.add(jv5);participantes.add(jv6);participantes.add(jv7);participantes.add(jv8);

        // Árbitros
        Participante arb1 = new Arbitro("ARB01", "Juan Carlos García González", "Española", 55);
        Participante arb2 = new Arbitro("ARB02", "Antonio Conde", "Española", 51);
        Participante arb3 = new Arbitro("ARB03", "Emilio Pérez Pizarro", "Española", 53);

        participantes.add(arb1);participantes.add(arb2);participantes.add(arb3);

    }





}
